# 😎 SMILEY CYMOR MD — v2.0.0 Legendary Edition

> _"No one does it better than me."_ — **Legendary Smiley Cymor**

> **An all-in-one WhatsApp bot** — 1300+ commands (counted directly from
> commands actually registered via `.totalfitur`, not a rough estimate), a
> full RPG system, advanced protection (including **Anti-NSFW**), and much
> more. Built on Baileys Multi-Device. Log in via **QR code** (default) or
> **pairing code**. Ready to deploy on **Render**, Pterodactyl, a VPS, or
> Termux.

> ⚠️ **Worth knowing before you deploy:** this bot uses an unofficial
> library (Baileys) to automate WhatsApp — not the official WhatsApp
> Business API. This technically violates WhatsApp's Terms of Service, and
> an account could get banned, though this is rare for reasonable use. It's
> recommended to use a secondary number, not your main one.

---

## ✨ Highlight Features v3.0.0

| Feature | Description |
|-------|-----------|
| 🔄 **Auto-Read** | Messages are automatically marked as read (blue tick) before the bot replies |
| ⌨️ **Auto-Typing** | A "typing..." indicator shows while the bot processes a command |
| ⏳ **Cooldown System** | Per-user, per-category anti-spam for commands, fully configurable |
| 🛡️ **Anti-Flood** | Blocks aggressive flooding (4 messages within 3 seconds) |
| 📊 **Analytics** | Stats on the most popular commands, user & group counts |
| 🎨 **Colored Logger** | Clean, readable terminal output |
| 🔁 **Smart Reconnect** | Exponential backoff — the longer it fails, the longer the delay before retrying |
| 📈 **Live Stats in Menu** | The main menu shows real-time data (users, groups, commands) |

---

## 📦 Feature Categories

### ⚔️ RPG (280+ commands)
- Create a character with 4 classes (Warrior, Mage, Archer, Rogue)
- Combat system: Hunt monsters, PvP Duels, Boss Raids, Dungeons
- Full economy: Shop, Bank, Transfer, Work, Rob
- Pet System, Quests, Achievements, Gacha, Expeditions
- Crafting, Refining, Training, Prestige
- Gambling: Gold betting & Lottery
- Global ranking & leaderboard

### 🛡️ Group Admin (300+ commands)
- Member management: Kick, Promote, Demote, Add, **Kick All**, **Warn All**
- Warning system with auto-kick + `.cekwarnall` / `.topwarn` / `.resetwarnall`
- Group mute (with duration) **+ individual per-member mute** (`.mutemember`)
- Group lock, plus granular locks per content type: Media, Stickers, Images,
  Video, Documents, Contacts, Location, Voice Notes, Audio, GIF, Polls
- Custom Welcome & Farewell messages with variables
- Slowmode (+ `.slowmodeoff`), Polls, Schedules, Reports, Auto-reply
- **Full protection suite**: Anti-spam, Anti-toxic (+ custom bad-word list
  per group), Anti-link (+ link allowlist), Anti-GB, Anti-ShortLink,
  Anti-Flood, **Anti-Link-Phishing**, **Anti-Gambling-Promo**,
  **Anti-Loan-Shark-Promo**, **Anti-Caps**, **Anti-Virtex**, **Anti-Tag**,
  **Anti-NSFW** (v3.2.0 — automatically detects & removes adult
  photos/videos/stickers + `.hapusnsfw` for manual removal, see its own
  section below) — status for all of these can be checked via
  `.grouplockstatus`
- **Per-member protection whitelist** (`.whitelistadd`) so specific members
  are exempt from all the protections above
- **Join Request Approval**: view/accept/reject join requests for groups
  set to "Admin Approval Required" mode (`.listrequest`, `.approverequest`,
  etc.)
- **Automatic daily group open/close schedule** (`.jadwalbuka` / `.jadwaltutup`)
- **Group settings backup/restore** (`.backupsetting` / `.restoresetting`)
- Change/remove group photo from chat (`.seticon`/`.hapusicon`), lock group
  info (`.lockinfo`), disappearing messages (`.ephemeral`)
- Group dashboard (`.groupsummary`), group age, admin count, member data
- Group activity statistics
- **Sider Detector**: detect members who never/rarely chat (`.sider`),
  mass-kick them all at once (`.kicksider`) — group admins are automatically
  excluded

### 🎮 Fun & Games (190+ commands)
- Mini games: Trivia, Word Scramble, Riddles, Higher-Lower
- Truth or Dare, WYR, Guess the Number, Slots, RPS
- Comedy: Dad Jokes, Funny Conspiracies, Roasts, Compliments
- Tarot, Fortune Cookie, Zodiac, Compatibility
- Word of the Day, Mood, Affirmations, Random Emoji

### 🛠️ Tools (220+ commands)
- Text: Upper/Lower/Reverse/Leet/ROT13 + 15 other transformations
- Encryption: Binary, Base64, Hex, Morse, Caesar, ASCII
- Math: Calculator, BMI, Primes, Factorial, Fibonacci, GCD/LCM
- Conversion: Length, Weight, Temperature
- Finance: Discounts, Split Bill, Tip calculator
- Validators: Email, Phone number, Credit card, Password strength
- Generators: Password, UUID, Random color, Random picker

### 🖼️ Media — Brat & IQC
- `.brat <text>` — a plain white **sticker** (WebP) with black text, in the
  style of the "brat" trend (Charli XCX). You can also reply to a text
  message and just type `.brat` with no extra argument.
- `.bratgreen <text>` — same as `.brat`, but with the green background from
  the original "Brat" album art.
- `.bratwhite <text>` — same as `.brat` (white background, black text).
- `.iqc <text>` — a WhatsApp-style chat bubble, sent as a regular image
  (not a sticker, since the shape isn't square).
- Brat images are generated via a remote API (`brat.siputzx.my.id`), then
  converted to a WebP sticker on the bot's side using `ffmpeg-static` — no
  extra compiler/native build needed, so installs stay lightweight on
  Pterodactyl.

> 💡 The brat variants are intentionally limited to just the 3 commands
> above (`.brat`/`.bratgreen`/`.bratwhite`). Other themed and video/animated
> variants are no longer available.

---

## 🚀 How to Deploy

> ⚙️ **Requirements:** Node.js **20.0.0 or higher** for every deployment
> method below (check with `node -v`). Baileys and some other dependencies
> no longer support Node 18 or below.

### 🌐 Render (the method used for QR code login)
1. Push this project to your own GitHub repo (see the **GitHub** section
   below if you haven't done this before).
2. In the [Render Dashboard](https://dashboard.render.com), click **New +**
   → **Web Service**, then pick your GitHub repo.
3. Fill in the configuration:
   - **Environment**: `Node`
   - **Build Command**: `npm install`
   - **Start Command**: `npm start`
   - **Instance Type**: `Free` is fine to try it out (see the limitations
     note below), `Starter` or above for serious/24-hour use
4. (Optional) Add these **Environment Variables**:
   - `OWNER_NUMBER` = your WhatsApp number (e.g. `6281234567890`) — so
     you're automatically set as Owner
   - `LOGIN_METHOD` = `pairing` if you'd rather use an 8-digit code instead
     of a QR code (default is already `qr`, so leave this unset if you want
     QR)
5. Click **Create Web Service** and wait for the build to finish.
6. Once the status is **Live**, open your Render URL
   (`https://your-service-name.onrender.com`) in a browser — the QR code
   page appears right away.
7. On your phone: WhatsApp → **Settings** → **Linked Devices** → **Link a
   Device**, then point your camera at the QR on that page.
8. Once scanned, the page automatically switches to "✅ Connected" and the
   bot is ready — try sending `.menu` to the bot's number.

> 💡 **Why does it need a web page for the QR code?** Render (and most
> "Web Service" hosts) require the process to bind to a single HTTP port
> for health checks. This bot already includes a small built-in HTTP
> server (`lib/loginServer.js`) just for that — no extra setup needed.

> ⚠️ **Render's free tier sleeps after ~15 minutes of no traffic**, which
> will drop the bot's WhatsApp connection. For a bot that needs to stay
> online 24/7, use a paid instance (Starter or above) or add an external
> ping service (e.g. UptimeRobot) that regularly hits your Render URL.

> 💡 **Where is the session stored?** The `session/` folder is created
> automatically the first time the bot runs, and holds the WhatsApp login
> credentials. On Render, disk storage is **not persistent** on the
> free/standard tier — if the service restarts/redeploys, you'll need to
> scan the QR again. For a session that survives redeploys, add a
> [Render Disk](https://render.com/docs/disks) and point `session/` to it,
> or upgrade to a plan that supports persistent disks.

### GitHub (pushing this project)
```bash
git init
git add .
git commit -m "Initial commit — Smiley Cymor MD"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/YOUR-REPO.git
git push -u origin main
```
> ⚠️ Before pushing: make sure `setting.js` doesn't contain any personal
> tokens/numbers if the repo is **public** — use Environment Variables on
> Render for sensitive data (see step 4 above) instead of writing them
> directly into the file.

### Pterodactyl Panel
1. Upload this project to your Pterodactyl server.
2. (Optional) Set the **Startup Variable** `LOGIN_METHOD` = `pairing` if
   you'd rather use an 8-digit code instead of a QR, then also fill in
   `NOMOR_HP` = your phone number (e.g. `628123456789`). By default,
   without this variable, the bot uses a QR code (check the console log
   for status messages, though the QR itself is easier to view via a
   browser — see the note below).
3. Start the bot — the pairing code (if `LOGIN_METHOD=pairing`) will
   appear in the console, or the bot will prepare a QR (see note)
4. Open WhatsApp → Settings → Linked Devices → Link with Phone Number
   (pairing) or Link a Device (QR)
5. Enter the code / scan within 60 seconds

> 💡 **Want to see the QR on Pterodactyl?** The Pterodactyl panel doesn't
> render a QR image in the console. The easiest option is still Render
> (see the section above), which has a built-in web page for that — or
> just use `LOGIN_METHOD=pairing` on Pterodactyl for a phone-number-based
> code that shows up as plain text in the console.

> 💡 **Forgot to set `NOMOR_HP` while using `LOGIN_METHOD=pairing`?** No
> problem — once the bot starts and detects the number hasn't been set
> (in ENV or `setting.js`), it will **ask directly in the console**: type
> the number (format `628xxxxxxxxxx`) and hit Enter, and the bot will
> continue on its own with pairing. If your panel's console can't send
> input to the bot (depends on the egg configuration), the bot will say so
> clearly in the log after a short wait — the fix is to set `NOMOR_HP` via
> a Startup Variable as in step 2 above, which always works on Pterodactyl
> regardless of whether the console supports direct input.

> 💡 **Still seeing lots of `npm warn deprecated` during install?** The
> main dependencies (Baileys, node-cache) have been updated to actively
> maintained versions, so warnings from those two should already be much
> reduced. Any remaining warnings usually come from deeper transitive
> dependencies (dependencies of dependencies) — this is normal for any
> Node project and **does not mean anything failed to install**; if you
> want a cleaner install log, run `npm install --loglevel=error`.

### VPS / Local
```bash
# Install dependencies
npm install

# Set your number in setting.js
# nomorPairing: '628xxx'

# Run
npm start
```

> 💡 `.brat`/`.bratgreen`/`.bratwhite`/`.antinsfw` (for video) need
> ffmpeg. By default this comes via `ffmpeg-static` (already in
> `package.json`, installed automatically via `npm install` above — no
> extra compiler/toolchain needed). If this package fails to
> install/run on your server, the related commands will give a clear
> message when called (instead of crashing the bot) — and since v3.2.1,
> the bot also automatically falls back to the system ffmpeg (from PATH)
> if one is available.

### 📱 Termux (Android) — v3.2.1
This bot can run directly from an Android phone via
[Termux](https://f-droid.org/packages/com.termux/) (install from F-Droid,
not the Play Store — the Play Store version is no longer updated), with no
VPS/panel needed at all.

```bash
# 1. Update Termux packages, then install Node.js LTS, git, and ffmpeg
pkg update -y && pkg upgrade -y
pkg install -y nodejs-lts git ffmpeg

# 2. Make sure Node is version 20 or above (see note below if not)
node -v

# 3. Go into the project folder (extracted/cloned), then install dependencies
cd Smiley-Cymor-MD
npm install

# 4. Set your number in setting.js (nomorPairing: '628xxx'), then run
npm start

# (optional but recommended) so Termux doesn't easily get killed by Android
# in the background when the screen is off:
termux-wake-lock
```

> 💡 **`node -v` still below 20?** Run `pkg install nodejs` (the latest
> version, not `-lts`) to get the newest version available in Termux's repo.

> 💡 **Why do I need to `pkg install ffmpeg` manually on Termux?**
> `ffmpeg-static` in `package.json` downloads an ffmpeg binary compiled for
> regular Linux glibc — that binary **won't run** on Android/Termux
> (Termux uses Bionic libc, different from glibc), even though `npm
> install` itself won't error out. Since v3.2.1, the bot automatically
> falls back to the SYSTEM ffmpeg (from `pkg install ffmpeg` above) if the
> `ffmpeg-static` binary is detected as invalid — so no extra setup is
> needed, and `.brat`/`.antinsfw` (video parts) still work normally on
> Termux.

> 💡 To keep the bot running even if the Termux app is closed/swiped away,
> run it inside a `tmux`/`screen` session (`pkg install tmux`), or set up
> Termux:Boot for auto-start after a phone restart.

---


## ⚙️ Configuration (setting.js)

All configuration lives in `setting.js`. The most important parts:

```js
ownerName:   'Your Name',
ownerNumber: '628xxx',      // Owner's number (no + or spaces) — or set via ENV OWNER_NUMBER
creatorName: 'Legendary Smiley Cymor',  // This bot's developer/brand name
botName:     'SMILEY CYMOR MD',
motto:       'No one does it better than me',
prefix:      '.',           // Change the prefix if needed
loginMethod: 'qr',          // 'qr' (default, scan via the web page) or 'pairing' (8-digit code)
nomorPairing: '628xxx',     // Only used when loginMethod = 'pairing'

autoRead:    true,          // Auto blue-tick read receipts
autoTyping:  true,          // Auto typing indicator
cooldownEnabled: true,      // Cooldown system
cooldowns: {
    rpg:   8000,            // RPG cooldown: 8 seconds
    admin: 2000,            // Admin cooldown: 2 seconds
    fun:   3000,            // Fun cooldown: 3 seconds
    tools: 1500,            // Tools cooldown: 1.5 seconds
    menu:   500,            // Menu cooldown: 0.5 seconds
},
```

---

## 📁 File Structure

```
bot-v3/
├── index.js              — Entry point (smart reconnect, banner)
├── setting.js            — Full configuration
├── features/
│   ├── protection.js     — Anti-GB, Link, Spam, Toxic, Flood
│   └── protectionExtra.js— 🆕 v3.1.0: Anti-Phishing/Promo/Gambling/Loan-shark/
│                            Caps/Virtex/Tag/Fake, whitelist, bad-word &
│                            link allowlist, per-member mute
├── lib/
│   ├── logger.js         — 🆕 Colored terminal logger
│   ├── cooldown.js       — 🆕 Per-user cooldown system
│   ├── messagePipeline.js— Auto-read, typing, cooldown check
│   ├── groupScheduler.js — 🆕 v3.1.0: automatic group open/close schedule
│   ├── db.js             — JSON database + analytics
│   ├── utils.js          — Helper functions
│   ├── roles.js          — Creator/Owner/Premium (roles)
│   ├── imageGen.js        — 🆕 Renders iqc pixels (no image dependency)
│   ├── stickerGen.js       — 🆕 Encodes WebP stickers via webp-wasm
│   ├── videoGen.js        — 🆕 Converts brat images (remote API) into WebP stickers via ffmpeg
│   ├── childBot.js       — Sub-bot manager
│   ├── rpgData.js        — RPG data (monsters, items, etc.)
│   └── rpgEngine.js      — RPG logic
└── commands/
    ├── index.js          — Router for all commands
    ├── menu.js            — 🆕 Redesigned menu
    ├── bratCommands.js    — 🆕 .brat, .bratgreen, .bratwhite, .iqc
    ├── rpgCommands*.js   — RPG commands (5 files)
    ├── adminCommands*.js — Admin commands (4 files — adminCommands4.js 🆕 v3.1.0)
    ├── funCommands*.js   — Fun commands (3 files)
    ├── toolsCommands*.js — Tools commands (3 files)
    └── ...
```

---

## 🛡️ Protection System

Enable per group with admin commands:

| Command | Function |
|---------|--------|
| `.antigb on/off` | Block other WhatsApp group links |
| `.antilink on/off` | Block all URLs (except domains in `.allowlinkadd`) |
| `.antishortlink on/off` | Block bit.ly, tinyurl, s.id, etc. |
| `.antilinkphising on/off` | Block phishing links/patterns (fake account verification, fake prize claims, etc.) |
| `.antispam on/off` | Block spam (6 messages/10 seconds) + Anti-Flood (4 messages/3 seconds) |
| `.antitoxic on/off` | Block offensive words (+ custom words via `.addbadword`) |
| `.antijudol on/off` | Block online gambling promotion (slots/lottery/etc.) |
| `.antipinjol on/off` | Block illegal online loan promotion |
| `.anticaps on/off` | Block excessive ALL-CAPS messages |
| `.antivirtex on/off` | Block "virus text" (zalgo/excessive unicode) |
| `.antitag on/off` | Block mass-mention spam from non-admins |
| `.antinsfw on/off` | Automatically detect & remove adult photos/videos/stickers (v3.2.0) |

Helper commands: `.resetprotection` (turn everything off),
`.grouplockstatus` (view full status), `.helpproteksi` (quick cheatsheet),
`.whitelistadd` (exempt one member from all the protections above).
Granular locks per content type (image/video/document/contact/location/
voice note/audio/GIF/poll) are available via `.lockimage`, `.lockvideo`,
etc. — see `.menuadmin` for the full list.

### 🔞 Anti-NSFW (v3.2.0)

An admin feature to automatically detect & remove adult photos/videos/
stickers, plus manual admin commands:

| Command | Function |
|---------|--------|
| `.antinsfw on/off` | Enable/disable automatic detection in this group |
| `.hapusnsfw` | Reply to a photo/video/sticker to force-delete it + issue a strike (no API needed) |
| `.cekstrikensfw @tag` | Check a member's NSFW strike count |
| `.resetnsfwstrike @tag` | Reset a member's NSFW strikes |
| `.setnsfwlimit [number]` | Set how many strikes trigger an auto-kick (default: 3) |

**Important note on AUTOMATIC detection**: `.hapusnsfw` (manual) always
works with no conditions. But for `.antinsfw on` to **detect adult content
by itself** (not just delete what an admin replies to), you need to fill
in a free API key in `setting.js` under `nsfwDetection`:

1. Sign up for a free account at https://console.pixlab.io
2. Get an API key from the dashboard
3. Fill it into `settings.nsfwDetection.apiKey` in `setting.js` (or the
   `NSFW_API_KEY` ENV variable, which is safer if you've ever shared
   `setting.js` with someone else)

As long as the API key isn't set, `.antinsfw on` can still be turned on
without error — just the automatic detection won't be active yet (this
system is intentionally **fail-open**: if the API isn't configured/fails/
times out, the bot will NOT delete people's messages at random, so it
never mistakenly deletes the wrong thing). Want to use a different
detection provider? Fill in `customApiUrl` in the same block — the API
contract details are in the comments of `lib/nsfwDetector.js`.

---

## 🎵 Notes on the `.play`, `.ig`, & `.tiktok` Features

The `.play` feature used to run on the `@distube/ytdl-core` library. As of
August 2025, **that repository has been archived** by its owner — meaning
there are no more updates to keep up with YouTube's anti-bot changes.
That's why, if you've ever seen an error like this:

```
❌ Failed to download audio:
Status code: 403
```

...that is **not a bug in this bot** — it's YouTube rejecting requests from
that now-abandoned library. Almost every WhatsApp bot still using
`ytdl-core`/`@distube/ytdl-core` runs into the same issue.

**The fix:** the `.play`, `.ig`, and `.tiktok` features all now use
[`yt-dlp`](https://github.com/yt-dlp/yt-dlp) — a separate project (not a
Node.js library) that gets updated far more often to keep up with changes
from YouTube/Instagram/TikTok, and this single binary covers all three
platforms at once (no separate dependency per platform needed). The bot
will **automatically download the `yt-dlp` binary** (the standalone Linux
build that bundles its own Python — you do NOT need to install Python on
your server/Pterodactyl) into a `bin/` folder the first time any of these
three commands is called. This process needs:

- Internet access from your server to `github.com` (just once, for the
  download).
- A few extra seconds on the FIRST call (downloading the binary).
  Subsequent calls (of any of the three commands) use the binary that's
  already there.

If your server doesn't have access to `github.com` (strict firewall,
etc.), manually download the `yt-dlp` (Linux) binary from the
[official releases page](https://github.com/yt-dlp/yt-dlp/releases/latest),
place it at `bin/yt-dlp` (a `bin/` folder next to `index.js`), and run
`chmod +x bin/yt-dlp`.

**If one of these features suddenly starts failing again** (YouTube/
Instagram/TikTok frequently change their mechanisms), it's most likely
that `yt-dlp` on your server has fallen behind. Delete the `bin/yt-dlp`
file, then run one of those commands again — the bot will automatically
download the latest version.

**About the "extract audio" button under `.ig`/`.tiktok` videos:** that's a
NATIVE WhatsApp client feature for ALL video messages (not something the
bot controls) — so it appears automatically without the bot doing
anything. WhatsApp is rolling this button out gradually, so not every
device/WhatsApp version has it yet — if it's missing on your device,
that's not a bot-side issue.

**About private content:** `.ig`/`.tiktok` can only download PUBLIC
content. Posts/accounts set to private by their owner can't be downloaded
(this isn't a bot limitation — it's enforced by Instagram/TikTok
themselves).

**Why `.ig` fails more often than `.tiktok`:** Instagram is far more
aggressive about restricting access without login compared to TikTok —
"login required" or "rate-limit reached" errors often show up even with a
correct, public link. This is an Instagram-side issue (they lock pages
behind a login page), not a bot bug — and it changes from day to day
depending on how aggressive Instagram is being at that moment. This bot
already handles it by:

- Using a special mobile user-agent for requests to Instagram (sometimes
  helps avoid that detection, though not always).
- Translating yt-dlp's technical errors ("exit code 1", "rate-limit",
  etc.) into clear messages — if you see a message like "Instagram is
  currently restricting access...", that's really on Instagram's side; try
  again in a few minutes or try a different link.

A 100% permanent fix for this would require **cookies from a real, logged-
in Instagram account** (see yt-dlp's docs on `--cookies-from-browser`/
`--cookies`), but that comes with risk (the account could get rate-limited/
flagged by Instagram) and needs manual maintenance (cookies expire), so
it's NOT enabled by default in this bot.

---

## 🔐 Notes on Frequently Corrupted Sessions (badSession)

**Why this happens:** Baileys (`useMultiFileAuthState`) writes MANY small
files to the `session/` folder every time an encryption key changes —
which is basically every time a message comes in or goes out. This is
official Baileys behavior (even their own official docs say this function
is "not recommended for production", and is only suitable for small bots).

If the Node process dies **exactly** while one of those files is being
written — a forced restart via Pterodactyl (clicking Restart/Kill), the
container getting OOM-killed, or a crash — that file ends up
half-written, i.e. corrupted. Once a SINGLE file is corrupted, Baileys
will treat the ENTIRE auth state as invalid (`badSession`) on the next
connection attempt.

**What's already been fixed in this bot:**

1. **Proper graceful shutdown** — previously, `SIGTERM`/`SIGINT` (the
   "polite" signals Pterodactyl sends on a normal Restart/Stop) called
   `process.exit()` immediately without waiting for anything, even though
   Baileys might still be writing files in the background. Now the bot
   `await`s the credential save finishing before actually shutting down.
2. **Auto-backup of the `session/` folder** — every time the connection
   opens successfully (and periodically every `sessionBackupIntervalMinutes`
   minutes, default 30, configurable in `setting.js`), the `session/`
   folder is copied to `session-backup/` — but ONLY if its contents are
   valid (has a `creds.json`), so a corrupted state never gets backed up.
   If `session/` ever does get corrupted, you have a backup to manually
   restore from (copy `session-backup/`'s contents into `session/`)
   without having to pair from scratch.

**What CANNOT be fixed from the code side:** a `SIGKILL` signal (`kill
-9`) — for example if Pterodactyl/the server force-kills the process with
no warning at all — cannot be intercepted by any Node process, so there's
no way to "rescue" a file write that's in progress in that case. This
isn't a bot limitation — it's a fundamental limitation of the operating
system/Node.js itself.

---

## ⚠️ Notes on "@lid" Accounts

WhatsApp is rolling out a new ID system called **LID (Linked
Identifier)**. Some accounts (usually new accounts or business accounts)
are sometimes recognized by the bot with an ID in the form `xxxxx@lid`
INSTEAD of a normal phone number (`628xxx@s.whatsapp.net`). The number in
front of `@lid` is **not the real phone number** — it's WhatsApp's
internal random ID.

This bot already tries to resolve `@lid` back to the real phone number
whenever WhatsApp provides that data (via the `participantPn`/`senderPn`
fields in Baileys). But this is a limitation of WhatsApp/Baileys itself,
not the bot — in private chats, **WhatsApp sometimes doesn't reveal the
real number at all**, and only "realizes" the true identity in later
messages.

If this happens to you (the Owner) or another user, the impact is:
- You run `.daftar` (register), but in another message `.nomorku`/another
  command gets blocked again as "not registered" — that's a sign WhatsApp
  sent a different ID for different messages from the same number.
- `.nomorku` will clearly tell you if your account is currently being
  detected as `@lid` (instead of silently showing that ID as if it were a
  real phone number).
- If this happens to the Owner/Creator's number, some commands might be
  rejected on certain messages for a while. Try sending a fresh regular
  text message (not a reply to an old message) — WhatsApp will usually go
  back to sending the normal phone-number identity after a few messages.

There isn't a 100% fix from Baileys' side for this issue as of when this
project was built — the bot will automatically improve as Baileys releases
further fixes for `@lid` mapping.

---

## ⚡ Changelog v2.0.1 (Smiley Cymor MD rebrand — connectivity fix)

- ✅ **Fixed "scans QR but won't connect" bug** — the rebrand accidentally
  pinned `@whiskeysockets/baileys` back down to the old legacy `6.7.23`
  release (see the v3.2.1 note below on why that version is deprecated).
  An outdated Baileys version is exactly what causes a phone to approve
  the QR/pairing successfully while the bot-side socket still gets
  disconnected right after (commonly surfaces as a `multideviceMismatch`
  error in the console). `package.json` now pins the exact, tested
  `6.17.16` release instead. If you already deployed the earlier zip: on
  Render/Pterodactyl, clear `node_modules` (or trigger a clean rebuild)
  and redeploy so the correct version actually gets installed, then scan
  the QR again.

---

## ⚡ Changelog v3.2.1

- ✅ **Minimum Node.js raised to v20.0.0** — set in `engines` in
  `package.json`. The latest Baileys version now requires this too.
- ✅ **Dependencies updated** — `@whiskeysockets/baileys` bumped from
  `6.7.23` (already marked *legacy* by its maintainer) to `^6.17.16` (the
  latest release on the same 6.x line, so NO breaking changes — deliberately
  NOT jumping to `7.0.0-rc`, since that's still an experimental/release
  candidate build with some reported connection-stability bugs). The
  6-year-unmaintained `node-cache` was replaced with its official
  successor, `@cacheable/node-cache` (1:1 compatible, just a renamed
  import). This change should significantly reduce the `npm warn
  deprecated` messages you see during install — any remaining warnings
  from deeper transitive dependencies are normal for any Node project.
- ✅ **Termux (Android) support** — see the "📱 Termux (Android)"
  subsection above for full install steps. Includes a fix in
  `lib/videoGen.js` to automatically fall back to the SYSTEM ffmpeg (`pkg
  install ffmpeg`) if the bundled `ffmpeg-static` binary doesn't run
  (common on Android, due to glibc vs Bionic libc differences) — so
  `.brat`/`.antinsfw` (video parts) keep working on Termux with no extra
  setup.

---

## ⚡ Changelog v3.2.0

- ✅ **Anti-NSFW** — a new admin feature to automatically detect & remove
  adult photos/videos/stickers entering a group (`.antinsfw on/off`), plus
  the manual `.hapusnsfw` command (reply then force-delete, no setup
  needed) and a strike/auto-kick system (`.cekstrikensfw`,
  `.resetnsfwstrike`, `.setnsfwlimit`). See the "🔞 Anti-NSFW" section
  above for how to enable automatic detection (needs a free API key).
- ✅ **Total commands pass 900+** — counted DIRECTLY from commands actually
  registered (not an estimate) via `.totalfitur`, plus 20 new commands:
  physics calculators (`.ohm`, `.energikinetik`, `.gayagravitasi`,
  `.jarakproyektil`, `.percepatan`), math (`.faktorprima`, `.fpbstep`,
  `.matrixtambah`, `.matrixkali`), converters (`.konversidata`,
  `.konversidaya`), health (`.persentaselemak`, `.pacelari`), and fun
  (`.shiozodiak`, `.artimimpi`, `.warnahoki`, `.elementzodiak`,
  `.namatim`, `.julukananime`, `.namakerajaan`).

---

## ⚡ Changelog v3.1.0

- ✅ **300+ New Admin Commands** — total feature count went from 900+ to
  **1200+**, almost all in the Admin/Group category (see `.menuadmin` &
  `.totalfitur`)
- ✅ **New Protections** — `.antilinkphising`, `.antijudol`,
  `.antipinjol`, `.anticaps`, `.antivirtex`, `.antitag`
- ✅ **Anti-Flood Finally Active** — the function existed for a while but
  was never actually wired into the message flow; now it runs
  automatically alongside `.antispam`
- ✅ **Granular Content Locks** — the old `.lockmedia`/`.lockstiker` still
  work, plus 9 new types: `.lockimage`, `.lockvideo`, `.lockdocument`,
  `.lockcontact`, `.locklocation`, `.lockvn`, `.lockaudio`, `.lockgif`,
  `.lockpoll`
- ✅ **Custom Bad-Word & Link Allowlist** — `.addbadword`/`.delbadword` to
  extend `.antitoxic` per group, `.allowlinkadd`/`.allowlinkdel` to
  exempt specific domains from `.antilink`
- ✅ **Protection Whitelist** — `.whitelistadd` exempts a specific member
  from all the protections above
- ✅ **Per-Member Mute** — `.mutemember` mutes one person without muting
  the whole group (different from the old `.mute`)
- ✅ **Kick All / Warn All** — `.kickall yakin` & `.warnall` for mass
  actions on all non-admins, plus `.cekwarnall`/`.topwarn`/`.resetwarnall`
- ✅ **Join Request Approval** — `.listrequest`, `.approverequest`,
  `.rejectrequest`, `.approveall`, `.rejectall` for groups set to "Admin
  Approval Required" mode
- ✅ **Automatic Group Open/Close Schedule** — `.jadwalbuka`/`.jadwaltutup`
  (checked every minute by `lib/groupScheduler.js`, view status with
  `.cekjadwalgrup`)
- ✅ **Group Settings Backup/Restore** — `.backupsetting`/`.restoresetting`
- ✅ **Change Group Photo from Chat** — `.seticon` (reply to an image)/
  `.hapusicon`, plus `.lockinfo`/`.unlockinfo` (restrict who can change
  group info) and `.ephemeral` (disappearing messages)
- ✅ **Group Dashboard** — `.groupsummary`, `.grouplockstatus`,
  `.groupage`, `.admincount`, `.groupcreator`, `.exportmember`, `.cekbot`
- ✅ **More Complete Ban List** — `.banlist` (view the bot's block list) &
  `.unbanall`, plus banned members are automatically removed again if they
  try to rejoin the group

## ⚡ Changelog v3.0.0

- ✅ **More Corruption-Resistant Sessions** — Graceful shutdown now waits
  for credential saving to finish (prevents corruption on restart), plus
  auto-backup of `session/` to `session-backup/` (see the "Notes on
  Frequently Corrupted Sessions" section above)
- ✅ **Registration Required** — `.daftar name.age` before other commands
  can be used (Owner/Creator bypass this)
- ✅ **`.brat` Is Now a Sticker** — black-and-white theme, sent as a real
  WebP sticker (not a regular image)
- ✅ **@lid Identity Fix** — more accurate resolution of the real phone
  number (see the "Notes on @lid Accounts" section above)
- ✅ **`.allmenu` Redesigned** — boxed layout per category, much tidier
- ✅ **Auto-Read + Auto-Typing** — makes the bot feel more alive
- ✅ **Cooldown System** — per user, per category, with an owner bypass
- ✅ **Anti-Flood** — more aggressive than regular anti-spam
- ✅ **Colored Logger** — Pterodactyl output is far more readable
- ✅ **Analytics** — tracks the most popular commands, users, groups
- ✅ **Redesigned Menu** — more informative, with real-time data
- ✅ **Enhanced Ping** — shows latency, runtime, statistics
- ✅ **Runtime Command** — shows the top 5 most popular commands
- ✅ **Exponential Backoff** — smarter reconnect behavior
- ✅ **Error Handling** — more robust, `uncaughtException` is now handled
- ✅ **Expanded Setting.js** — 20+ new configuration options
- ✅ **`.totalfitur`** — automatically shows the bot's total command/feature count
- ✅ **`.sider` / `.kicksider`** — detect & kick group members who never/rarely chat
- ✅ **`.play` Migrated to yt-dlp** — `@distube/ytdl-core` has been
  archived (no more updates), causing constant "Status code: 403" errors.
  Replaced with the `yt-dlp` binary (auto-downloaded on first use, see the
  "Notes on the `.play` Feature" section below)
- ✅ **`.iqc` Now a Real WhatsApp Bubble** — previously themed like
  iMessage (blue, tail on the left), now a real WhatsApp-green bubble
  (tail on the right, dark text), plus more natural text wrapping (no
  longer one word per line for short sentences)
- ✅ **`.ig` & `.tiktok` (new)** — download Instagram/TikTok videos via a
  direct link OR by replying to a message containing a link, with an info
  caption (title/Requested by/Powered by) — using the same yt-dlp
  infrastructure as `.play`

---

_Made with 😎 — SMILEY CYMOR MD —「No one does it better than me」_


### Admin Menu Patch
The Admin menu now shows additional admin commands that are actually
registered, with no placeholders like admin143.
